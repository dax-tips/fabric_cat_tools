import sempy
import sempy.fabric as fabric
import pandas as pd
import numpy as np
sempy.fabric._client._utils._init_analysis_services()
from sempy.fabric._cache import _get_or_create_workspace_client
from sempy.fabric._client._connection_mode import ConnectionMode
import Microsoft.AnalysisServices.Tabular as TOM
from sempy.fabric._client import DatasetXmlaClient
import System
from .dataset import list_tables
from .dataset import get_shared_expression

# datasetName = 'V1_All_Tables_Import' # Original semantic model name
# newDatasetName = 'V1_All_Tables_Import_migrated' # New semantic model name

def migrate_tables(datasetName,newDatasetName):
    from .dataset import list_tables
    from .dataset import get_shared_expression

    workspaceId = fabric.get_workspace_id()
    workspaceName = fabric.resolve_workspace_name(workspaceId)
    tom_server = _get_or_create_workspace_client(workspaceName).get_dataset_client(newDatasetName, ConnectionMode.XMLA)._get_connected_dataset_server(readonly=False)

    shEx = get_shared_expression()

    dfC = fabric.list_columns(datasetName)
    dfT = list_tables(datasetName)

    for d in tom_server.Databases:
        if d.Name == newDatasetName:
            print(f"Updating '{d.Name}' based on '{datasetName}'...")
            m = d.Model
            print(f"\nCreating shared expression parameter...")
            exp = TOM.NamedExpression()
            eName = 'DatabaseQuery'
            exp.Name = eName
            exp.Kind = TOM.ExpressionKind.M
            exp.Expression = shEx
            if not any(e.Name == eName for e in m.Expressions):
                m.Expressions.Add(exp)
                print(f"'{eName}' shared expression has been added.")

            for tName in dfC['Table Name'].unique():
                tType = dfT.loc[(dfT['Name'] == tName), 'Type'].iloc[0]
                tDC = dfC.loc[(dfC['Table Name'] == tName), 'Data Category'].iloc[0]
                tDesc = dfC.loc[(dfC['Table Name'] == tName), 'Description'].iloc[0]

                # Create the table with its columns for regular tables that do not already exist in the model
                if tType == 'Table' and not any(t.Name == tName for t in m.Tables):
                    tbl = TOM.Table()        
                    tbl.Name = tName
                    tbl.DataCategory = tDC
                    tbl.Description = tDesc

                    ep = TOM.EntityPartitionSource()
                    ep.Name = tName
                    ep.EntityName = tName
                    ep.ExpressionSource = exp

                    part = TOM.Partition()
                    part.Name = tName # this needs to be the lakehouse table name
                    part.Source = ep
                    part.Mode = TOM.ModeType.DirectLake

                    tbl.Partitions.Add(part)

                    columns_in_table = dfC.loc[dfC['Table Name'] == tName, 'Column Name'].unique()
            
                    print(f"\nCreating columns for '{tName}' table...")           
                    for cName in columns_in_table:
                        scName = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Source'].iloc[0]
                        cType = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Type'].iloc[0]
                        cHid = bool(dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Hidden'].iloc[0])
                        cDataType = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Data Type'].iloc[0]

                        if cType == 'Data' and not any(t.Name == tName and c.Name == cName for t in m.Tables for c in t.Columns):
                            col = TOM.DataColumn()
                            col.Name = cName
                            col.IsHidden = cHid
                            col.SourceColumn = scName #this needs to be the lakehouse column name
                            col.DataType = System.Enum.Parse(TOM.DataType, cDataType)

                            tbl.Columns.Add(col)
                            print(f"The '{tName}'[{cName}] column has been added.")
            
                    m.Tables.Add(tbl)
                    print(f"The '{tName}' table has been added.")

            m.SaveChanges()
            print(f"\nAll regular tables and columns have been added to the model.")