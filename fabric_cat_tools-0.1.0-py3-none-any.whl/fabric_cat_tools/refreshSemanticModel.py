import sempy
import sempy.fabric as fabric
import time

def refresh_semantic_model(datasetName):
        
    requestID = fabric.refresh_dataset(datasetName, refresh_type = 'full')

    while True:
        requestDetails = fabric.get_refresh_execution_details(datasetName,requestID)
        status = requestDetails.status

        # Check if the refresh has completed
        if status == 'Completed':
            break

        time.sleep(3)

    print(f"Refresh for the '{datasetName}' semantic model is complete.")