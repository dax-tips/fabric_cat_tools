import sempy
import sempy.fabric as fabric
import pandas as pd
from sempy.fabric._cache import _get_or_create_workspace_client

def list_tables(datasetName, workspaceName = None):

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    workspace_client = _get_or_create_workspace_client(workspaceName)
    ds = workspace_client.get_dataset(datasetName)
    m = ds.Model

    header = pd.DataFrame(columns=['Name', 'Type', 'Hidden', 'Data Category', 'Description', 'Refresh Policy', 'Source Expression'])
    df = pd.DataFrame(header)

    for t in m.Tables:
        tableType = "Table"
        rPolicy = bool(t.RefreshPolicy)
        sourceExpression = None
        if str(t.CalculationGroup) != "None":
            tableType = "Calculation Group"
        else:
            for p in t.Partitions:
                if str(p.SourceType) == "Calculated":
                    tableType = "Calculated Table"

        if rPolicy:
            sourceExpression = t.RefreshPolicy.SourceExpression

        new_data = {'Name': t.Name, 'Type': tableType,'Hidden': t.IsHidden, 'Data Category': t.DataCategory, 'Description': t.Description, 'Refresh Policy': rPolicy, 'Source Expression': sourceExpression}
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df